package com.example.campuspulseai.domain.DTO.Request;

public class CreateClubRequest {
    private String clubName;
    private String clubDescription;
    private String logoUrl;

}

