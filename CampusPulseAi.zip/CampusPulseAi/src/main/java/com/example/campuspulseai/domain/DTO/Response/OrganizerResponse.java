package com.example.campuspulseai.domain.DTO.Response;

public class OrganizerResponse {
    private String organizerName;
    private long organizerId;
}
