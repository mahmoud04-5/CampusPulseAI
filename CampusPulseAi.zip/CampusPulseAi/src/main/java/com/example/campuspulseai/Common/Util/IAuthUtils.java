package com.example.campuspulseai.Common.Util;

public interface IAuthUtils {
}
