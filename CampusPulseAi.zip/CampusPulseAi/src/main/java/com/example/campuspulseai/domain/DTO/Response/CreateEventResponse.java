package com.example.campuspulseai.domain.DTO.Response;

public class CreateEventResponse {
    private String title;
    private long eventId;
}
