package com.example.campuspulseai.domain.Enum;

public enum Role {
    USER,
    ADMIN,
    MODERATOR
}

