package com.example.campuspulseai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusPulseAiApplicationTests {

    @Test
    void contextLoads() {
    }

}
